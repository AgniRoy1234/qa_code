import pandas as pd 
import re 
import os
from google import genai
from openai import OpenAI
from dotenv import load_dotenv 
load_dotenv()

doctors=pd.read_excel('doctors.xlsx')
hospitals=pd.read_excel('hospital.xlsx')
hospitals_dict=hospitals.to_dict(orient='records')
doctors_dict=doctors.to_dict(orient='records')
prompt=""
with open('gemini_prompt.txt') as f:
    prompt=f.read() 
prompt1=f"""{prompt}\n HOSPITALS:{hospitals_dict} \n DOCTORS:{doctors_dict}"""


def get_answer_from_gemini(prompt):
    ''' 
    function to call gemini api to get answer
    '''
    gemini_key=os.getenv('GEMINI_API')
    client = genai.Client(api_key=gemini_key)
    response = client.models.generate_content(
    model="gemini-2.0-flash", contents=prompt)
    return response.text


def get_answer(question):
    total_prompt=f"""{prompt1} QUESTION:{question}"""
    answer=get_answer_from_gemini(total_prompt) 
    return answer 
