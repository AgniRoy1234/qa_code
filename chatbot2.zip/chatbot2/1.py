import streamlit as st
from gemini_fetch_answer import get_answer 
import re 
def chatbot_gemini():

    st.title("Ask your question")

    user_input = st.text_input("Enter your text:")

    if user_input:
        user_input_lower = user_input.lower()
        response = get_answer(user_input_lower) 

        if response:
            st.write("Response:", response)
        else:
            st.write("No specific response found for that input.")

if __name__ == "__main__":

    chatbot_gemini()